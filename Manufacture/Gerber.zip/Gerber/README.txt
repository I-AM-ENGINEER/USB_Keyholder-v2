Сопроводительный документ для проекта USB_Keyholder
E-mail для связи: sdwad6@gmail.com

Количество плат - 5
Количество слоев - 2
Материал - FR-4
Итоговая толщина платы - 1.6 mm +- 10%

Единицы измерения - миллиметры
Толщина меди во всех слоях - 35 um
Минимальный диаметр сквозного отверстия - 0.4 mm
Шелкография на обеих слоях
Без слепых отверстий

Порядок слоев и толщины:

USB_keyholder.GTO - TOP шелкография
USB_keyholder.GTS - TOP вскрытие маски
USB_keyholder.GTL - TOP сигнальный слой

USB_keyholder.GBL - BOTTOM сигнальный слой
USB_keyholder.GBS - BOTTOM вскрытие маски
USB_keyholder.GBO - BOTTOM шелкография

USB_keyholder.GKO            - контур платы
USB_keyholder-RoundHoles.TXT - файл сверловки 1
USB_keyholder-SlotHoles.TXT  - файл сверловки 2



Цвет маски: зелёный
