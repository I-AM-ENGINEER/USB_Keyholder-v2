Сопроводительный документ для проекта keyholder_v2
E-mail для связи - sdwad6@gmail.com
Срочное производство

Количество плат - 20
Количество слоев - 2
Размер плат - 45x16 мм

Толщина меди - 35 мкм
Толщина FR4  - 1,5 мм
Примерная итоговая толщина платы - 1,6 мм
Финишное покрытие - ПОС-61
Цвет шелкографии - белый
Цвет маски - зелёный
Шелкография на обоих сторонах
Поштучное разделение не требуется 

Порядок слоев:
------------------------------------------------------------------------------------------
Layer Extension     	    Layer Description                      
------------------------------------------------------------------------------------------
keyholder-F_Silkscreen.gbr  Top Silkscreen
keyholder-F_Mask.gbr        Top Mask
keyholder-F_Cu.gbr  	    Top Layer
keyholder-B_Cu.gbr          Bottom Layer
keyholder-B_Mask.gbr        Bottom Mask
keyholder-B_Silkscreen.gbr  Bottom Silkscreen
keyholder-Edge_Cuts.gbr     Board Outline
------------------------------------------------------------------------------------------